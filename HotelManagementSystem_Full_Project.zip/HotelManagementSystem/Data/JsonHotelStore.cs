using System.Text.Json;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.Data;

/// <summary>
/// Small file-based data store. It uses JSON so the project runs without a separate database server
/// or third-party NuGet packages. Data is saved in App_Data/hotel-data.json.
/// </summary>
public class JsonHotelStore
{
    private readonly string _filePath;
    private readonly object _sync = new();
    private StoreData _data;

    private sealed class StoreData
    {
        public List<Room> Rooms { get; set; } = new();
        public List<Guest> Guests { get; set; } = new();
        public List<Booking> Bookings { get; set; } = new();
        public int NextRoomId { get; set; } = 1;
        public int NextGuestId { get; set; } = 1;
        public int NextBookingId { get; set; } = 1;
    }

    public JsonHotelStore(IWebHostEnvironment environment)
    {
        var directory = Path.Combine(environment.ContentRootPath, "App_Data");
        Directory.CreateDirectory(directory);
        _filePath = Path.Combine(directory, "hotel-data.json");
        _data = Load();
        if (_data.Rooms.Count == 0 && _data.Guests.Count == 0 && _data.Bookings.Count == 0)
        {
            Seed();
            Save();
        }
    }

    private StoreData Load()
    {
        try
        {
            if (!File.Exists(_filePath)) return new StoreData();
            return JsonSerializer.Deserialize<StoreData>(File.ReadAllText(_filePath))
                   ?? new StoreData();
        }
        catch
        {
            return new StoreData();
        }
    }

    private void Save()
    {
        var options = new JsonSerializerOptions { WriteIndented = true };
        File.WriteAllText(_filePath, JsonSerializer.Serialize(_data, options));
    }

    private void Seed()
    {
        _data.Rooms.AddRange(new[]
        {
            new Room { Id = 1, RoomNumber = "101", RoomType = "Standard", Capacity = 2, PricePerNight = 1800, IsAvailable = true, Description = "Comfortable room for two guests." },
            new Room { Id = 2, RoomNumber = "201", RoomType = "Deluxe", Capacity = 3, PricePerNight = 2800, IsAvailable = true, Description = "Spacious room with a city view." },
            new Room { Id = 3, RoomNumber = "301", RoomType = "Suite", Capacity = 4, PricePerNight = 4500, IsAvailable = true, Description = "Premium suite for families." }
        });
        _data.Guests.AddRange(new[]
        {
            new Guest { Id = 1, FullName = "Aarav Patel", Email = "aarav@example.com", Phone = "9876543210", Address = "Surat, Gujarat" },
            new Guest { Id = 2, FullName = "Diya Shah", Email = "diya@example.com", Phone = "9876501234", Address = "Bardoli, Gujarat" }
        });
        _data.NextRoomId = 4;
        _data.NextGuestId = 3;
        _data.NextBookingId = 1;
    }

    public (List<Room> Rooms, List<Guest> Guests, List<Booking> Bookings) Dashboard()
    {
        lock (_sync)
            return (_data.Rooms.ToList(), _data.Guests.ToList(), _data.Bookings.ToList());
    }

    public List<Room> GetRooms() { lock (_sync) return _data.Rooms.OrderBy(r => r.RoomNumber).ToList(); }
    public Room? GetRoom(int id) { lock (_sync) return _data.Rooms.FirstOrDefault(r => r.Id == id); }
    public void AddRoom(Room room) { lock (_sync) { room.Id = _data.NextRoomId++; _data.Rooms.Add(room); Save(); } }
    public bool UpdateRoom(Room room) { lock (_sync) { var old = _data.Rooms.FirstOrDefault(x => x.Id == room.Id); if (old is null) return false; old.RoomNumber = room.RoomNumber; old.RoomType = room.RoomType; old.Capacity = room.Capacity; old.PricePerNight = room.PricePerNight; old.IsAvailable = room.IsAvailable; old.Description = room.Description; Save(); return true; } }
    public bool DeleteRoom(int id) { lock (_sync) { if (_data.Bookings.Any(b => b.RoomId == id && b.Status != "Cancelled")) return false; var removed = _data.Rooms.RemoveAll(r => r.Id == id) > 0; if (removed) Save(); return removed; } }

    public List<Guest> GetGuests() { lock (_sync) return _data.Guests.OrderBy(g => g.FullName).ToList(); }
    public Guest? GetGuest(int id) { lock (_sync) return _data.Guests.FirstOrDefault(g => g.Id == id); }
    public void AddGuest(Guest guest) { lock (_sync) { guest.Id = _data.NextGuestId++; _data.Guests.Add(guest); Save(); } }
    public bool UpdateGuest(Guest guest) { lock (_sync) { var old = _data.Guests.FirstOrDefault(x => x.Id == guest.Id); if (old is null) return false; old.FullName = guest.FullName; old.Email = guest.Email; old.Phone = guest.Phone; old.Address = guest.Address; Save(); return true; } }
    public bool DeleteGuest(int id) { lock (_sync) { if (_data.Bookings.Any(b => b.GuestId == id && b.Status != "Cancelled")) return false; var removed = _data.Guests.RemoveAll(g => g.Id == id) > 0; if (removed) Save(); return removed; } }

    public List<Booking> GetBookings() { lock (_sync) return _data.Bookings.OrderByDescending(b => b.Id).ToList(); }
    public Booking? GetBooking(int id) { lock (_sync) return _data.Bookings.FirstOrDefault(b => b.Id == id); }
    public bool IsRoomAvailable(int roomId, DateTime checkIn, DateTime checkOut, int? ignoreBookingId = null)
    {
        lock (_sync)
            return !_data.Bookings.Any(b => b.RoomId == roomId && b.Status != "Cancelled" && b.Id != ignoreBookingId && checkIn < b.CheckOut && checkOut > b.CheckIn);
    }
    public string? AddBooking(Booking booking)
    {
        lock (_sync)
        {
            if (!_data.Guests.Any(g => g.Id == booking.GuestId)) return "Please select a valid guest.";
            var room = _data.Rooms.FirstOrDefault(r => r.Id == booking.RoomId);
            if (room is null) return "Please select a valid room.";
            if (booking.CheckOut.Date <= booking.CheckIn.Date) return "Check-out must be after check-in.";
            if (!IsRoomAvailable(booking.RoomId, booking.CheckIn, booking.CheckOut)) return "That room is already booked for the selected dates.";
            booking.Id = _data.NextBookingId++;
            booking.TotalAmount = room.PricePerNight * (booking.CheckOut.Date - booking.CheckIn.Date).Days;
            booking.Status = "Confirmed";
            _data.Bookings.Add(booking);
            Save();
            return null;
        }
    }
    public bool CancelBooking(int id) { lock (_sync) { var booking = _data.Bookings.FirstOrDefault(b => b.Id == id); if (booking is null) return false; booking.Status = "Cancelled"; Save(); return true; } }
}

using HotelManagementSystem.Data;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HotelManagementSystem.Controllers;

public class BookingsController : Controller
{
    private readonly JsonHotelStore _store;
    public BookingsController(JsonHotelStore store) => _store = store;

    public IActionResult Index()
    {
        var bookings = _store.GetBookings();
        var data = _store.Dashboard();
        ViewBag.Guests = data.Guests.ToDictionary(g => g.Id, g => g.FullName);
        ViewBag.Rooms = data.Rooms.ToDictionary(r => r.Id, r => $"{r.RoomNumber} - {r.RoomType}");
        return View(bookings);
    }

    public IActionResult Create()
    {
        PopulateLists();
        return View(new Booking { CheckIn = DateTime.Today, CheckOut = DateTime.Today.AddDays(1) });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Create(Booking booking)
    {
        if (booking.CheckOut.Date <= booking.CheckIn.Date)
            ModelState.AddModelError(nameof(booking.CheckOut), "Check-out must be after check-in.");
        if (!_store.IsRoomAvailable(booking.RoomId, booking.CheckIn, booking.CheckOut))
            ModelState.AddModelError(nameof(booking.RoomId), "This room is already booked for those dates.");
        if (!ModelState.IsValid)
        {
            PopulateLists();
            return View(booking);
        }

        var error = _store.AddBooking(booking);
        if (error is not null)
        {
            ModelState.AddModelError("", error);
            PopulateLists();
            return View(booking);
        }
        TempData["Success"] = "Booking created successfully.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Cancel(int id)
    {
        if (_store.CancelBooking(id)) TempData["Success"] = "Booking cancelled.";
        else TempData["Error"] = "Booking was not found.";
        return RedirectToAction(nameof(Index));
    }

    private void PopulateLists()
    {
        ViewBag.Guests = new SelectList(_store.GetGuests(), "Id", "FullName");
        ViewBag.Rooms = new SelectList(_store.GetRooms().Where(r => r.IsAvailable), "Id", "RoomNumber");
    }
}

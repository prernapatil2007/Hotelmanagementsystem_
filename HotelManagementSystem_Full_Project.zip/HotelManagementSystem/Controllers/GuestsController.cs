using HotelManagementSystem.Data;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementSystem.Controllers;

public class GuestsController : Controller
{
    private readonly JsonHotelStore _store;
    public GuestsController(JsonHotelStore store) => _store = store;

    public IActionResult Index() => View(_store.GetGuests());
    public IActionResult Create() => View(new Guest());

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Create(Guest guest)
    {
        if (_store.GetGuests().Any(g => g.Email.Equals(guest.Email, StringComparison.OrdinalIgnoreCase)))
            ModelState.AddModelError(nameof(guest.Email), "This email is already registered.");
        if (!ModelState.IsValid) return View(guest);
        _store.AddGuest(guest);
        TempData["Success"] = "Guest registered successfully.";
        return RedirectToAction(nameof(Index));
    }

    public IActionResult Edit(int id)
    {
        var guest = _store.GetGuest(id);
        return guest is null ? NotFound() : View(guest);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Edit(Guest guest)
    {
        if (_store.GetGuests().Any(g => g.Id != guest.Id && g.Email.Equals(guest.Email, StringComparison.OrdinalIgnoreCase)))
            ModelState.AddModelError(nameof(guest.Email), "This email is already registered.");
        if (!ModelState.IsValid) return View(guest);
        if (!_store.UpdateGuest(guest)) return NotFound();
        TempData["Success"] = "Guest details updated.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Delete(int id)
    {
        if (!_store.DeleteGuest(id)) TempData["Error"] = "Guest could not be deleted. Cancel their bookings first.";
        else TempData["Success"] = "Guest deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
}

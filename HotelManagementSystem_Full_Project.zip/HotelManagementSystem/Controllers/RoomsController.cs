using HotelManagementSystem.Data;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementSystem.Controllers;

public class RoomsController : Controller
{
    private readonly JsonHotelStore _store;
    public RoomsController(JsonHotelStore store) => _store = store;

    public IActionResult Index() => View(_store.GetRooms());

    public IActionResult Create() => View(new Room());

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Create(Room room)
    {
        if (_store.GetRooms().Any(r => r.RoomNumber.Equals(room.RoomNumber, StringComparison.OrdinalIgnoreCase)))
            ModelState.AddModelError(nameof(room.RoomNumber), "This room number already exists.");
        if (!ModelState.IsValid) return View(room);
        _store.AddRoom(room);
        TempData["Success"] = "Room added successfully.";
        return RedirectToAction(nameof(Index));
    }

    public IActionResult Edit(int id)
    {
        var room = _store.GetRoom(id);
        return room is null ? NotFound() : View(room);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Edit(Room room)
    {
        if (_store.GetRooms().Any(r => r.Id != room.Id && r.RoomNumber.Equals(room.RoomNumber, StringComparison.OrdinalIgnoreCase)))
            ModelState.AddModelError(nameof(room.RoomNumber), "This room number already exists.");
        if (!ModelState.IsValid) return View(room);
        if (!_store.UpdateRoom(room)) return NotFound();
        TempData["Success"] = "Room updated successfully.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Delete(int id)
    {
        if (!_store.DeleteRoom(id)) TempData["Error"] = "Room could not be deleted. Cancel its bookings first.";
        else TempData["Success"] = "Room deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
}

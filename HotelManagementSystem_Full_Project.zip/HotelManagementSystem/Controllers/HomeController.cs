using System.Diagnostics;
using HotelManagementSystem.Data;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementSystem.Controllers;

public class HomeController : Controller
{
    private readonly JsonHotelStore _store;
    public HomeController(JsonHotelStore store) => _store = store;

    public IActionResult Index()
    {
        var data = _store.Dashboard();
        ViewBag.RoomCount = data.Rooms.Count;
        ViewBag.GuestCount = data.Guests.Count;
        ViewBag.BookingCount = data.Bookings.Count(b => b.Status != "Cancelled");
        ViewBag.AvailableRooms = data.Rooms.Count(r => r.IsAvailable);
        ViewBag.RecentBookings = data.Bookings.OrderByDescending(b => b.Id).Take(5).ToList();
        ViewBag.Guests = data.Guests;
        ViewBag.Rooms = data.Rooms;
        return View();
    }

    public IActionResult Error() => View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}

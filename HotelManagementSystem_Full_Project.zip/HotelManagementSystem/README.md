# StayEase Hotel Management System

A beginner-friendly ASP.NET Core MVC hotel management project.

## Features
- Dashboard with room, guest, and booking counts
- Room CRUD: add, edit, delete, and list rooms
- Guest CRUD: register, edit, delete, and list guests
- Booking creation with date-conflict checking and automatic total calculation
- Booking cancellation
- JSON file storage in `App_Data/hotel-data.json` (no MySQL/SQL Server installation or extra NuGet packages required)
- Sample rooms and guests added automatically on first run

## Requirements
- .NET 10 SDK
- Visual Studio Code with the C# extension (recommended)

## Run in VS Code
1. Extract the ZIP file.
2. In VS Code choose **File → Open Folder** and select the extracted `HotelManagementSystem` folder (the folder containing `HotelManagementSystem.csproj`).
3. Open **Terminal → New Terminal**.
4. Run:

   ```powershell
   dotnet restore
   dotnet run --launch-profile http
   ```

5. Open `http://localhost:5138` in your browser.

If port 5138 is already in use, edit `Properties/launchSettings.json` and change the port in `applicationUrl`, then use the new port in the browser.

## Data
Records are saved in `App_Data/hotel-data.json`. Keep a backup of this file if you need to preserve your data. This is a simple learning/demo project and does not include user login, payment processing, or production-grade database security.

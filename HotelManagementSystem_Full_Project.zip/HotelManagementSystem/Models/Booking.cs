using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models;

public class Booking
{
    public int Id { get; set; }

    [Required]
    [Display(Name = "Guest")]
    public int GuestId { get; set; }

    [Required]
    [Display(Name = "Room")]
    public int RoomId { get; set; }

    [Required, DataType(DataType.Date)]
    [Display(Name = "Check-in")]
    public DateTime CheckIn { get; set; } = DateTime.Today;

    [Required, DataType(DataType.Date)]
    [Display(Name = "Check-out")]
    public DateTime CheckOut { get; set; } = DateTime.Today.AddDays(1);

    public string Status { get; set; } = "Confirmed";

    public decimal TotalAmount { get; set; }
}

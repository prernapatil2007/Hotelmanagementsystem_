using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models;

public class Guest
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    [Display(Name = "Full Name")]
    public string FullName { get; set; } = "";

    [Required, EmailAddress, StringLength(150)]
    public string Email { get; set; } = "";

    [Required, Phone, StringLength(25)]
    public string Phone { get; set; } = "";

    [StringLength(250)]
    public string? Address { get; set; }
}

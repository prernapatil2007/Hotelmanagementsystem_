using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models;

public class Room
{
    public int Id { get; set; }

    [Required, StringLength(20)]
    [Display(Name = "Room Number")]
    public string RoomNumber { get; set; } = "";

    [Required]
    [Display(Name = "Room Type")]
    public string RoomType { get; set; } = "Standard";

    [Range(1, 20)]
    public int Capacity { get; set; } = 2;

    [Range(0, 1000000)]
    [DataType(DataType.Currency)]
    public decimal PricePerNight { get; set; } = 1500;

    public bool IsAvailable { get; set; } = true;

    [StringLength(300)]
    public string? Description { get; set; }
}
